"use strict"

module.exports = async (context, callback) => {
    return {status: "ziptest/template"}
}
